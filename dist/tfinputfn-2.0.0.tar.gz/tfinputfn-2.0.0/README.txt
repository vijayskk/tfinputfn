This is a package for making input functions for tensorflow when using Linear Regression.

This package requires tensorflow v2 to work.

The input parameters are data_df, label_df, num_epochs=10, shuffle=True, batch_size=32,shufflefac=1000.